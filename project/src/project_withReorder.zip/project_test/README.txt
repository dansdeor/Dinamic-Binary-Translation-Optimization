On Fabian - 308141340
dan Sdeor - 209509181

Instructions: 
1. Create dir '<pindir>/sorce/tools/hw2' and Copy 'ex2.cpp' to it along with makefiles and txt.c (all in dir src)
2. Run command: gcc -o tst tst.c
3. Run command: '<pindir>/sorce/tools/hw2/make ex2.test'
4. Run command: ./tst -t 
For other test, do step 5:
5. Run command: '<pindir> -t '<pindir>/sorce/tools/hw2/obj-intel64/ex2.so <bzip2_dir>/bzip2 -k -f  *insert input files*